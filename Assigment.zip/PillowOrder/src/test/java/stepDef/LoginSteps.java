package stepDef;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;



@RunWith(Cucumber.class)
public class LoginSteps {
	
	     WebDriver driver;

	    @Given("^user is on demomidtrans home page$")
	    public void user_is_on_demomidtranscom_page() throws Throwable {
	        
	    	System.setProperty("webdriver.chrome.driver","C:\\Users\\sasin\\eclipse-workspace\\PillowOrder\\chromedriver.exe");
			driver= new ChromeDriver();
			driver.get("https://demo.midtrans.com/");
			driver.manage().window().maximize();
	    	
	    }

	    @When("^user click on Buy Now Button$")
	    public void user_click_on_buy_now_button() throws Throwable {
	    	
	    	driver.findElement(By.xpath("//a[normalize-space()='BUY NOW']")).click();
	       
	    }

	    @Then("^user click on Continue$")
	    public void user_click_on_continue() throws Throwable {
	    	
	    	driver.findElement(By.xpath("//div[@class='cart-checkout']")).click();
	    	
	    	Thread.sleep(3000);
	    	
	    	driver.switchTo().alert();
	    	
	    	Thread.sleep(3000);
	    	
	        driver.switchTo().frame(0);
	        driver.findElement(By.xpath("//a[class='button-main-content'][span='Continue')]")).click();
	    	driver.findElement(By.xpath("//a[class='list-title text-actionable-bold']")).click();
	    		       
	    }

	    @Then("^user enter the card details \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	    public void user_enter_the_card_details_something_and_something_and_something_and_something(String cardnumber, String expiry_date, String cvv) {
	       
	    	driver.switchTo().frame(0);
	    	driver.findElement(By.name("cardnumber")).click();
	    	driver.findElement(By.xpath("//input[placeholder='MM / YY']")).click();
	    	driver.findElement(By.xpath("//input[inputmode='numeric']")).click();
	    	
	    	driver.switchTo().frame(1);
	    	 driver.findElement(By.xpath("//a[class='text-button-main'][span='Pay Now')]")).click();
	    }

	    @Then("^user clicks on CHECKOUT Button$")
	    public void user_clicks_on_checkout_button() throws Throwable {
	    	
	    	driver.findElement(By.id("PaRes")).sendKeys("112233");
	    	driver.findElement(By.xpath("//button[@type='submit']")).click();
	    	
	    	
	       
	    }

	}

